// var name = "Paul E. Johnson"
// var formattedName = HTMLheaderName.replace("%data%", name);

// var role = "Web Developer";
// var formattedRole = HTMLheaderRole.replace("%data%", role);

// $("#header").prepend(formattedRole);
// $("#header").prepend(formattedName);

// var skills = ["awesomness", "programming", "teaching", "JS"];

// $("#main").append(skills);

// $("#main").append(skills[0]);

// $("#main").append(skills.length);

// var bio = {
//   	"name" : "Paul",
//   	"age" : 40,
//  	"skills" : skills
// };

// $("#main").append(bio.name);
// $("#main").append(bio.age);
// $("#main").append(bio.skills);



// if(bio.skills.length > 0)  {

//  	$("#header").append(HTMLskillsStart);

//  	var formattedSkill = HTMLskills.replace("%data%", bio.skills[0]);
//  	$("#skills").append(formattedSkill);
//  	formattedSkill = HTMLskills.replace("%data%", bio.skills[1]);
//  	$("#skills").append(formattedSkill);
//  	formattedSkill = HTMLskills.replace("%data%", bio.skills[2]);
//  	$("#skills").append(formattedSkill);
//  	formattedSkill = HTMLskills.replace("%data%", bio.skills[3]);
//  	$("#skills").append(formattedSkill);

// }

// var cameron = {};
// cameron.job = "course dev";

// var makeCourse = function() {
// 	// make a course
// 	console.log("Made a course");

// }
// var courses = 0;
// while(cameron.job === "course dev") {
// 	makeCourse();
// 	courses = courses + 1;
// 	if(courses === 10) {
// 		cameron.job = "learning specialist";
// 	}
// }

// console.log(cameron.job);

// var bio = {
//  	"name": "Paul E. Johnson",
//  	"role": "Web Developer",
//  	"contacts": {
//  	"mobile": "010-6559-2117",
//  	"email": "paul.m.r.johnson@gmail.com",
//  	"github": "pejohnson76",
//  	"twitter": "@paulmrjohnson",
//  	"location": "Andong",
//  	},
//  	"welcomeMsg": "We shall discuss, then, how to live a thousand years without worry",
//  	"skills": ["Castitas", "Temperantia", "Caritas", "Industria", "Patientia", "Benevolentia", "Humilitas"],
//  	"bioPic": "images/paul.jpg"
// }

var bio = {
	"name": "Paul E. Johnson",
	"role": "Web Developer",
	"contacts": {
		"mobile": "+82 010-6559-2117",
		"email": "paul.m.r.johnson@gmail.com",
		"github": "pejohnson76",
		"twitter": "@paulmrjohnson",
		"location": "Daegu, Korea",
		"welcomeMessage": " 'We shall discuss, then, how to live a hundred years without worry.' "
	},
	"skills": [
		"Castitas", "Temperantia", "Caritas", "Industria"
	],
	"biopic": "images/paul.jpg",

	display: function () {
		$("#header").prepend(HTMLheaderRole.replace("%data%", bio.role));
		$("#header").prepend(HTMLheaderName.replace("%data%", bio.name));
		$("#topContacts, #footerContacts").append(HTMLmobile.replace("%data%", bio.contacts.mobile));
		$("#topContacts, #footerContacts").append(HTMLemail.replace("%data%", bio.contacts.email));
		$("#topContacts, #footerContacts").append(HTMLgithub.replace("%data%", bio.contacts.github));
		$("#header").append(HTMLbioPic.replace("%data%", bio.biopic));
		$("#header").append(HTMLwelcomeMsg.replace("%data%", bio.contacts.welcomeMessage));
		$("#topContacts").append(HTMLtwitter.replace("%data%", bio.contacts.twitter));
		$("#topContacts").append(HTMLlocation.replace("%data%", bio.contacts.location));
		$("#header").append(HTMLskillsStart);
		bio.skills.forEach(function (skill) {
			$("#skills:last").append(HTMLskills.replace("%data%", skill));
		});
	}
};

bio.display()

var work = {
	"jobs": [
		{
			"employer": "Dream Language",
			"title": "Contract Corporate Communications Consultant",
			"location": "Seoul, South Korea",
			"dates": "March 2014 - March 2016",
			"description": "Helped put in place the right communication plan with the adapted media. Generated a source of volunteers via social media campaigns and web presence. Developed messaging required for various phases of the project. Reached out to the local media when necessary."
		},
		{
			"employer": "Andong National University",
			"title": "English as a Foreign Language Lecturer",
			"location": "Andong, South Korea",
			"dates": "March 2013 - February 2014",
			"description": "Classroom management; planning, preparing and delivering lessons to a range of classes and age groups; preparing and setting tests, examination papers and exercises; marking and providing appropriate feedback on oral and written work; devising, writing and producing new materials, including audio and visual resources; organising and getting involved in social and cultural activities such as sports competitions, school parties, dinners and excursions; attending and contributing to training sessions; participating in marketing events for the language school; preparing information for inspection visits and other quality assurance exercises; freelance teaching on a one-to-one basis; basic administration, such as keeping student registers and attendance records."
		}
	],
	display: function () {
		for (var job in work.jobs) {
			$("#workExperience").append(HTMLworkStart);
			$(".work-entry:last").append(HTMLworkEmployer.replace("%data%", work.jobs[job].employer + HTMLworkTitle.replace("%data%", work.jobs[job].title)));
			$(".work-entry:last").append(HTMLworkDates.replace("%data%", work.jobs[job].dates));
			$(".work-entry:last").append(HTMLworkLocation.replace("%data%", work.jobs[job].location));
			$(".work-entry:last").append(HTMLworkDescription.replace("%data%", work.jobs[job].description));
		}
	}
};

work.display();

var projects = {
	"projects": [
		{
			"title": "Korean Minisitry of Education EFL project",
			"dates": "December 2015 - February 2017",
			"description": "Helped developed state of the art speech recognition technology for a CAPT system to be incorporated into a CALL system for Korean learners of English.",
			"images": [
				"images/Ministry_of_Education.jpg", "images/genie_tutor.jpg",
			]
		}
	],
	display: function () {
		for (var project in projects.projects) {
			$("#projects").append(HTMLprojectStart);
			$(".project-entry:last").append(HTMLprojectTitle.replace("%data%", projects.projects[project].title));
			$(".project-entry:last").append(HTMLprojectDates.replace("%data%", projects.projects[project].dates));
			$(".project-entry:last").append(HTMLprojectDescription.replace("%data%", projects.projects[project].description));
			$(".project-entry:last").append(HTMLprojectImage.replace("%data%", projects.projects[project].images[0]));
			$(".project-entry:last").append(HTMLprojectImage.replace("%data%", projects.projects[project].images[1]));
		}
	}
};

projects.display();


// var education = {
//  	"schools": [
//  		{
//  			"name": "Seoul National University",
//  			"city": "Gwanak-gu, Seoul",
//  			"degree": "Masters",
//  			"majors": ["Linguistics"],
//  			"dates": 2017,
//  			"url": "http://hosting01.snu.ac.kr/~linguist/?page_id=192"
//  		},
//  		{
//  			"name": "Georgia State University",
//  			"city": "Atlanta, GA",
//   			"degree": "BBA",
//   			"majors": ["Finance"],
//   			"dates": 2002,
//   			"url": "www.gsu.edu"
//   		}	
//   	],
//   	"onlineCourses": [
//   		{
//   			"title": "Intro to Programming NanoDegree",
//   			"dates": 2017,
//   			"url": "https://www.udacity.com/course/intro-to-programming-nanodegree--nd000"
//   		}
//   	]
// }

var education = {
	"schools": [
		{
			"name": "Seoul National University",
			"location": "Seoul, South Korea",
			"degree": "Master of Arts",
			"majors": [
				"Linguistics"
			],
			"dates": 2017,
			"url": "http://hosting01.snu.ac.kr/~linguist/?page_id=192"
		},
		{
			"name": "Georgia State University",
			"location": "Atlanta, GA",
			"degree": "Bachelor of Business Administration",
			"majors": [
				"Finance"
			],
			"dates": 2002,
			"url": "http://http://www.gsu.edu/"
		},
		{
			"name": "Kennesaw State University",
			"location": "Kennesaw, GA",
			"degree": "Bachelor of Arts",
			"majors": [
				"International Affairs"
			],
			"dates": 1999,
			"url": "http://www.kennesaw.edu/"
		}
	],
	"onlineCourses": [
		{
			"title": "Intro to Programming NanoDegree",
			"school": "Udacity",
			"date": 2017,
			"url": "https://www.udacity.com/course/intro-to-programming-nanodegree--nd000"
		}
	],
	displaySchools: function () {
		for (var school in education.schools) {
			$("#education").append(HTMLschoolStart);
			$(".education-entry:last").append(HTMLschoolName.replace("%data%", education.schools[school].name) + HTMLschoolDegree.replace("%data%", education.schools[school].degree));
			$(".education-entry:last").append(HTMLschoolDates.replace("%data%", education.schools[school].dates));
			$(".education-entry:last").append(HTMLschoolLocation.replace("%data%", education.schools[school].location));
			$(".education-entry:last").append(HTMLschoolMajor.replace("%data%", education.schools[school].majors));
		}
	},
	displayOnlineCourses: function () {
		for (var course in education.onlineCourses) {
			$("#education").append(HTMLonlineClasses);
			$("#education").append(HTMLschoolStart);
			$(".education-entry:last").append(HTMLonlineTitle.replace("%data%", education.onlineCourses[course].title) + HTMLonlineSchool.replace("%data%", education.onlineCourses[course].school));
			$(".education-entry:last").append(HTMLonlineDates.replace("%data%", education.onlineCourses[course].date));
			$(".education-entry:last").append(HTMLonlineURL.replace("%data%", education.onlineCourses[course].url));
		}
	}
};

education.displaySchools();
education.displayOnlineCourses();

// var work = {
//   	"jobs": [
//   		{
//   			"employer": "Dream Language",
//   			"title": "Native English Speaker",
//   			"dates": "March 2014 - February 2015",
//   			"description": ""
//   		},
//   		{
//   			"employer": "Andong National University",
//   			"title": "English Lecturer",
//   			"dates": "March 2013 - February 2014",
//   			"description": ""
//   		}
//   	]
// }

// var projects = {
//   	"projects": [
//   		{
//   			"title": "Korean Ministry of Education English Education Project",
//   			"dates": "December 2015 - February 2017",
//   			"description": "",
//   			"images": [
//   				"",
//   				""
//   			]
//   		}
//   	]
// }

// function displayWork() {
//   	for (job in work.jobs) {
//   		// create new div for work experience
//   		$("workExperience".append(HTMLworkStart);
//   		// concat employer and title
//   		var formattedEmployer = HTMLworkEmployer.replace("%data%", work.jobs[job].employer);
//   		var formattedTitle = HTMLworkTitle.replace("%data%", work.jobs[job].title);
//   		var formattedEmployerTitle = formattedEmployer + formattedTitle;
//   		$(".work-entry:last"),append(formattedEmployerTitle);
 	
//   		var formattedDates
//  	}
//  }
// }

$("#mapDiv").append(googleMap);

//functions for various features

function locationizer(work_obj) {
	var locationArray = [];

	for (var job in work_obj.jobs) {
		var newLocation = work_obj.jobs[job].location;
		locationArray.push(newLocation);
	}
	return locationArray;
}

function inName(name) {
	name = name.trim().split(" ");
	name[name.length - 1] = name[name.length - 1].toUpperCase();
	name[0] = name[0].slice(0, 1).toUpperCase() + name[0].slice(1).toLocaleLowerCase();
	return name[0] + " " + name[name.length - 1];
}